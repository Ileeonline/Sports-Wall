import 'package:flutter/material.dart';

class SportNewsScreen extends StatefulWidget {
  const SportNewsScreen({super.key});

  @override
  State<SportNewsScreen> createState() => _SportNewsScreenState();
}

class _SportNewsScreenState extends State<SportNewsScreen> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold();
  }
}
