// ignore_for_file: unused_element

class Sports {
  String name;
  String sportIcon;

  Sports({
    required this.name,
    required this.sportIcon,
  });

  String get _name => name;
  String get _sportIcon => sportIcon;
}

List<Sports> sportsList = [
  Sports(
    name: 'Football',
    sportIcon: 'assets/icons/football.png',
  ),
  Sports(
    name: 'Basketball',
    sportIcon: 'assets/icons/basketball.png',
  ),
  Sports(
    name: 'Hockey',
    sportIcon: 'assets/icons/hockey.png',
  ),
  Sports(
    name: 'Baseball',
    sportIcon: 'assets/icons/baseball.png',
  ),
  Sports(
    name: 'Handball',
    sportIcon: 'assets/icons/handball.png',
  ),
  Sports(
    name: 'Volleyball',
    sportIcon: 'assets/icons/volly.png',
  ),
  Sports(
    name: 'Tennis',
    sportIcon: 'assets/icons/tennis.png',
  ),
  Sports(
    name: 'Rugby',
    sportIcon: 'assets/icons/rugby.png',
  ),
  Sports(
    name: 'Tennis',
    sportIcon: 'assets/icons/tennis.png',
  ),
  Sports(
    name: 'Baseball',
    sportIcon: 'assets/icons/baseball.png',
  ),
  Sports(
    name: 'Tennis',
    sportIcon: 'assets/icons/tennis.png',
  ),
];

